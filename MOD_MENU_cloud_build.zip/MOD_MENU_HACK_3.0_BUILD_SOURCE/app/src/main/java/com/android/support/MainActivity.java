package com.android.support;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(24, 24, 24, 24);
        TextView info = new TextView(this);
        info.setText("MOD MENU HACK 3.0\n\nНажми кнопку, чтобы запустить плавающее меню.\n\nВажно: исходный архив не содержит игровых обработчиков чит-функций.");
        info.setGravity(Gravity.CENTER);
        layout.addView(info);
        Button start = new Button(this);
        start.setText("Запустить меню");
        start.setOnClickListener(v -> Main.Start(MainActivity.this));
        layout.addView(start);
        setContentView(layout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If the user returned from the overlay permission screen, start the menu.
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M
                || android.provider.Settings.canDrawOverlays(this)) {
            // Do not repeatedly start the service on every resume unless requested.
        }
    }
}
